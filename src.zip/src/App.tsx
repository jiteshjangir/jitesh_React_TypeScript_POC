import { Route, Routes } from "react-router-dom";
import Home from "./Home";
import Details from "./Details"
import IndividualCustomerRecord from "./components/individualCustomer/IndividualCustomerRecord";



function App() {
  return (
    <div className="App">
      <Home />
      <Routes>
          <Route path="/IndividualCustomerRecord" element={<IndividualCustomerRecord />} />
          <Route path="/Details" element={<Details />} />
      </Routes>
    </div>
  );
}

export default App;
