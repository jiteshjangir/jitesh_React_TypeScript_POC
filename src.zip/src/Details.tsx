import IndividualCustomerDetails from "./components/individualCustomer/IndividualCustomerDetails";

const CustomerDetails = () => {
    return (
    <div>
        <IndividualCustomerDetails />
    </div>);
  };
  
  export default CustomerDetails;