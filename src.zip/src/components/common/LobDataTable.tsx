import ContactDataTable from './ContactDataTable'

const LobDataTable = () => {
  return (
      <div>
        <div>
          <div className='LOB-Info'>
            <span>Line of Business - Life</span>
          </div>
          <div className='Lob-Data'>
            <ContactDataTable />
          </div>
        </div>
        <div className='Lob-GI'>
          <div>
            <span className='Lob-GI-Text'>Line of Business - GI</span>
          </div>
          <div className='Lob-Data-GI'>
            <ContactDataTable />
          </div>
        </div>
        <div className='Lob-EB'>
          <div>
            <span className='Lob-GI-Text'>Line of Business - EB</span>
          </div>
          <div className='Lob-Data-GI'>
            <ContactDataTable />
          </div>
        </div>
        <div className='Lob-Pension'>
          <div>
            <span className='Lob-GI-Text'>Line of Business - Pension</span>
          </div>
          <div className='Lob-Data-GI'>
            <ContactDataTable />
          </div>
        </div>
        <div className='Lob-Vitality'>
          <div>
            <span className='Lob-GI-Text'>Line of Business - Vitality</span>
          </div>
          <div className='Lob-Data-GI'>
            <ContactDataTable />
          </div>
        </div>
        <div className='Lob-CIAM'>
          <div>
            <span className='Lob-GI-Text'>Line of Business - CIAM</span>
          </div>
          <div className='Lob-Data-GI'>
            <ContactDataTable />
          </div>
        </div>
      </div>
  );
};

export default LobDataTable;