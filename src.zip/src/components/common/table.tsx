import React from "react";

function objectKeys<T extends {}>(obj: T) {
  return Object.keys(obj).map((objKey) => objKey as keyof T);
}

type PrimitiveType = string | Symbol | number | boolean;

// Type guard for the primitive types which will support printing
// out of the box
function isPrimitive(value: any): value is PrimitiveType {
  return (
    typeof value === "string" ||
    typeof value === "number" ||
    typeof value === "boolean" ||
    typeof value === "symbol"
  );
}

/** Component */

interface MinTableItem {
  label: string;
}

interface TableProps<T extends MinTableItem> {
  items: T[];
}

export default function Table<T extends MinTableItem>(props: TableProps<T>) {
  function renderRow(item: T) {
    return (
      <tr>
        {objectKeys(item).map((itemProperty) => {
          return (
            <td className="table-column-style">{isPrimitive(item[itemProperty]) ? item[itemProperty] : ""}</td>
          );
        })}
      </tr>
    );
  }

  return (
    <table>
      <tbody>{props.items.map(renderRow)}</tbody>
    </table>
  );
}
