import * as React from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';

const Columns = [
    { field: 'policyNo', name: 'Policy No.'},
    { field: 'connectedPartyName', name: 'Connected Party Name'},
    { field: 'relationshipType', name: 'Relationship Type'}
]

const rows = [
  { policyNo: 'B123456789', connectedPartyName: 'Chan Mei Me', relationshipType:'Beneficiary Dependent' },
  { policyNo: 'B123456789', connectedPartyName: 'Chan Mei Me', relationshipType:'Beneficiary Dependent' }
];

export default function ConnectedPartyDataTable() {
  return (
    <TableContainer component={Paper}>
      <Table>
        <TableHead>
          <TableRow>
            { Columns.map(( columns) => (
                <TableCell key={columns.name}>{columns.name}</TableCell>
            ))}
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((row) => (
            <TableRow key={row.policyNo}>
              <TableCell>{row.policyNo}</TableCell>
              <TableCell>{row.connectedPartyName}</TableCell>
              <TableCell>{row.relationshipType}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
