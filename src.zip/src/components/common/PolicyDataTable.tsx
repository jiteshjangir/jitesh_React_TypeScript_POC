import * as React from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';

const Columns = [
    { field: 'policyNo', name: 'Policy No.'},
    { field: 'policyCountryCode', name: 'Policy Country Code'},
    { field: 'policyType', name: 'Policy Type'},
    { field: 'policyStatus', name: 'Policy Status'},
    { field: 'policyInitialEffectiveDate', name: 'Policy Initial Effective Date'},
    { field: 'payeeName', name: 'Payee Name'},
    { field: 'longPayeeName', name: 'Long Payee Name'},
    { field: 'payeeCountry', name: 'Payee Country'},
    { field: 'payeeRiskLevel', name: 'Payee Risk Level'}
]

const rows = [
  { policyNo: 'B123456789', policyCountryCode: 852, policyType:'Individual', policyStatus: 'Active', policyInitialEffectiveDate: '11/12/2003', payeeName: 'Chan Tai Man, Json', longPayeeName: 'Chan Tai Man, Json', payeeCountry: 'Hong Kong', payeeRiskLevel: 'Low' },
  { policyNo: 'B123456789', policyCountryCode: 852, policyType:'Individual', policyStatus: 'Active', policyInitialEffectiveDate: '11/12/2003', payeeName: 'Chan Tai Man, Json', longPayeeName: 'Chan Tai Man, Json', payeeCountry: 'Hong Kong', payeeRiskLevel: 'Low' }
];

export default function PolicyDataTable() {
  return (
    <TableContainer component={Paper}>
      <Table>
        <TableHead>
          <TableRow>
            { Columns.map(( columns) => (
                <TableCell key={columns.name}>{columns.name}</TableCell>
            ))}
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((row) => (
            <TableRow key={row.policyNo}>
              <TableCell>{row.policyNo}</TableCell>
              <TableCell>{row.policyCountryCode}</TableCell>
              <TableCell>{row.policyType}</TableCell>
              <TableCell>{row.policyStatus}</TableCell>
              <TableCell>{row.policyInitialEffectiveDate}</TableCell>
              <TableCell>{row.payeeName}</TableCell>
              <TableCell>{row.longPayeeName}</TableCell>
              <TableCell>{row.payeeCountry}</TableCell>
              <TableCell>{row.payeeRiskLevel}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
