import * as React from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';

const Columns = [
    { field: 'policyNo', name: 'Policy No.'},
    { field: 'mobilePhoneNo', name: 'Mobile Phone No.'},
    { field: 'emailAddress', name: 'Email Address'},
    { field: 'preferredCorrespondenceMethod', name: 'Preferred Correspondence Method'},
    { field: 'preferredLanguage', name: 'Preferred Language'},
    { field: 'mainOfficeTelNo', name: 'Main Office Tel No.'},
    { field: 'faxNo', name: 'Fax No.'},
    { field: 'contactforVerification', name: 'Contact for Verification'}

]

const rows = [
  { policyNo: 'B123456789', mobilePhoneNo:85292221111, emailAddress:'aialobcontact@aia.com', preferredCorrespondenceMethod: 'Email', preferredLanguage: 'English', mainOfficeTelNo: 85227778888, faxNo: 125215, contactforVerification: 85292221111 },
  { policyNo: 'B123456789', mobilePhoneNo:85292221111, emailAddress:'aialobcontact@aia.com', preferredCorrespondenceMethod: 'Email', preferredLanguage: 'English', mainOfficeTelNo: 85227778888, faxNo: 125215, contactforVerification: 85292221111 }
];

export default function ContactDataTable() {
  return (
    <TableContainer component={Paper}>
      <Table>
        <TableHead>
          <TableRow>
            { Columns.map(( columns) => (
                <TableCell key={columns.name}>{columns.name}</TableCell>
            ))}
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((row) => (
            <TableRow key={row.policyNo}>
              <TableCell>{row.policyNo}</TableCell>
              <TableCell>{row.mobilePhoneNo}</TableCell>
              <TableCell>{row.emailAddress}</TableCell>
              <TableCell>{row.preferredCorrespondenceMethod}</TableCell>
              <TableCell>{row.preferredLanguage}</TableCell>
              <TableCell>{row.mainOfficeTelNo}</TableCell>
              <TableCell>{row.faxNo}</TableCell>
              <TableCell>{row.contactforVerification}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
