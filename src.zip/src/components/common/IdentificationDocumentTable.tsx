import * as React from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';

const Columns = [
    { field: 'IdType', name: 'ID Type'},
    { field: 'IdNumber', name: 'ID Number'},
    { field: 'IdIssuingDate', name: 'ID Issuing Date'},
    { field: 'IdExpiryDate', name: 'ID Expiry Date'},
    { field: 'IdStatus', name: 'ID Status'},
    { field: 'IdCopyIndicator', name: 'ID Copy Indicator'}
]

const rows = [
  { IdType: 'HKID', IdNumber: 'A123456(7)', IdIssuingDate:'02/03/2003',
  IdExpiryDate: '02/03/2023', IdStatus: 'Active', IdCopyIndicator: 'Y'}
 ];

export default function IdentificationDocumentTable() {
  return (
    <TableContainer component={Paper}>
      <Table>
        <TableHead>
          <TableRow>
            { Columns.map(( columns) => (
                <TableCell key={columns.name}>{columns.name}</TableCell>
            ))}
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((row) => (
            <TableRow key={row.IdNumber}>
              <TableCell>{row.IdType}</TableCell>
              <TableCell>{row.IdNumber}</TableCell>
              <TableCell>{row.IdIssuingDate}</TableCell>
              <TableCell>{row.IdExpiryDate}</TableCell>
              <TableCell>{row.IdStatus}</TableCell>
              <TableCell>{row.IdCopyIndicator}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
