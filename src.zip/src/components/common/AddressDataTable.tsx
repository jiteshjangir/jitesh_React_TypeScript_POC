import * as React from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';

const Columns = [
    { field: 'policyNo', name: 'Policy No.'},
    { field: 'countryofResidence', name: 'Country of Residence'},
    { field: 'countryofResidenceStatus', name: 'Country of Residence Status'},
    { field: 'residentialAddress', name: 'Residential Address'},
    { field: 'countryofCorrespondenceAddress', name: 'Country of Correspondence Address'},
    { field: 'correspondenceAddress', name: 'Correspondence Address'},
    { field: 'mailCode', name: 'Mail Code'},
    { field: 'businessAddres', name: 'Business Addres'}

]

const rows = [
  { policyNo: 'B123456789', countryofResidence:'Hong Kong', countryofResidenceStatus:'Hong Kong',
  residentialAddress: 'AIA Tower, 183 Electric Rd, North Point', countryofCorrespondenceAddress: 'Hong Kong',
  correspondenceAddress: 'AIA Tower, 183 Electric Rd, North Point', mailCode: '-', businessAddres: 'AIA Tower, 183 Electric Rd, North Point' },
  { policyNo: 'B123456789', countryofResidence:'Hong Kong', countryofResidenceStatus:'Hong Kong',
  residentialAddress: 'AIA Tower, 183 Electric Rd, North Point', countryofCorrespondenceAddress: 'Hong Kong',
  correspondenceAddress: 'AIA Tower, 183 Electric Rd, North Point', mailCode: '-', businessAddres: 'AIA Tower, 183 Electric Rd, North Point' }
];

export default function AddressDataTable() {
  return (
    <TableContainer component={Paper}>
      <Table>
        <TableHead>
          <TableRow>
            { Columns.map(( columns) => (
                <TableCell key={columns.name}>{columns.name}</TableCell>
            ))}
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((row) => (
            <TableRow key={row.policyNo}>
              <TableCell>{row.policyNo}</TableCell>
              <TableCell>{row.countryofResidence}</TableCell>
              <TableCell>{row.countryofResidenceStatus}</TableCell>
              <TableCell>{row.residentialAddress}</TableCell>
              <TableCell>{row.countryofCorrespondenceAddress}</TableCell>
              <TableCell>{row.correspondenceAddress}</TableCell>
              <TableCell>{row.mailCode}</TableCell>
              <TableCell>{row.businessAddres}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
