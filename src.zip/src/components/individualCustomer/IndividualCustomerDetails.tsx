import '../Styles/IndividualCustomerRecord.css'
import Address from './details/Address';
import BasicInformation from './details/BasicInformation'
import Contact from './details/Contact'
import Name from './details/Name';
import IdentificationDocument from './details/IdentificationDocument';
import OccupationEmployment from './details/OccupationEmployment';
import ConnectedParty from './details/ConnectedParty'
import Policy from './details/Policy';
import HealthIndicator from './details/HealthIndicator'
import OtherIndicator from './details/OtherIndicator'
import USCitizen from './details/USCitizen'

const IndividualCustomerDetails = () => {
  return (
    <div className='Individual-Customer-Detail'>
        <div className='HeaderText'>
          <span className='Customer-Record-Detail-Text-Title'>Customer Record Details - C0000099991</span>
        </div>
        <div className='BasicInformation'>
          <BasicInformation />
        </div>
        <div className='Contact-Page'>
          <Contact />
        </div>
        <div className='Name-Page'>
          <Name />
        </div>
        <div className='Address-Page'>
          <Address />
        </div>
        <div className='IdDocument-Page'>
          <IdentificationDocument />
        </div>
        <div className='OccupationEmployment-Page'>
          <OccupationEmployment />
        </div>
        <div className='ConnectedParty-Page'>
          <ConnectedParty />
        </div>
        <div className='Policy-Page'>
          <Policy />
        </div>
        <div className='HealthIndicator-Page'>
          <HealthIndicator />
        </div>
        <div className='OtherIndicator-Page'>
          <OtherIndicator />
        </div>
        <div className='USCitizen-Page'>
          <USCitizen />
        </div>
    </div>
  );
}


export default IndividualCustomerDetails;


