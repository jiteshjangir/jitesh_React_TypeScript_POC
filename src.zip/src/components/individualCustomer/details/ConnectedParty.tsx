import ConnectedPartyDataTable from '../../common/ConnectedPartyDataTable'

const ConnectedParty = () => {
  return (
      <div>
        <div className='Search-Text-Title'>
          <span>Connected Party</span>
        </div>
        <div>
        <div>
          <div className='ConnectedParty-LOB-Info'>
            <span>Line of Business - Life</span>
          </div>
          <div className='ConnectedParty-Lob-Data-Life'>
            <ConnectedPartyDataTable />
          </div>
        </div>
        <div className='ConnectedParty-Lob-GI'>
          <div>
            <span className='ConnectedParty-Lob-GI-Text'>Line of Business - GI</span>
          </div>
          <div className='ConnectedParty-Lob-Data-GI'>
            <ConnectedPartyDataTable />
          </div>
        </div>
        <div className='ConnectedParty-Lob-EB'>
          <div>
            <span className='ConnectedParty-Lob-GI-Text'>Line of Business - EB</span>
          </div>
          <div className='ConnectedParty-Lob-Data-GI'>
            <ConnectedPartyDataTable />
          </div>
        </div>
        <div className='ConnectedParty-Lob-Pension'>
          <div>
            <span className='ConnectedParty-Lob-GI-Text'>Line of Business - Pension</span>
          </div>
          <div className='ConnectedParty-Lob-Data-GI'>
            <ConnectedPartyDataTable />
          </div>
        </div>
        <div className='ConnectedParty-Lob-Vitality'>
          <div>
            <span className='ConnectedParty-Lob-GI-Text'>Line of Business - Vitality</span>
          </div>
          <div className='ConnectedParty-Lob-Data-GI'>
            <ConnectedPartyDataTable />
          </div>
        </div>
        <div className='ConnectedParty-Lob-CIAM'>
          <div>
            <span className='ConnectedParty-Lob-GI-Text'>Line of Business - CIAM</span>
          </div>
          <div className='ConnectedParty-Lob-Data-GI'>
            <ConnectedPartyDataTable />
          </div>
        </div>
      </div>  
      </div>
  );
};
  
export default ConnectedParty;