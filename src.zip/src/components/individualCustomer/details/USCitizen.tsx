import Table from "../../common/table";

const stockItems = [
  { label: "US Citizen SSN No.", value: "-"},
  { label: "US Citizen Effective Date", value: "-"},
  { label: "US Citizen Source Policy", value: "-"},
  { label: "W8/W9 Type", value: "-"},
  { label: "USCI Sign Date for W8", value: "-"},
  { label: "Recalcitrant Account No.", value: "-"},
  { label: "Certificate Lost Nationality", value: "-"},
  { label: "US Citizen Form", value: "-"},
  { label: "US Citizen Update Cycle Date", value: "-"},
  { label: "US Citizen Source IWS Request", value: "N"},
  {label:'USCI Request Letter Date', value: '-'},
  {label:'USCI Sign Date for W9', value: '-'},
  {label:'W8 Entity', value: '-'},
  {label:'Recalcitrant Account Update', value: '-'}
];

const middleIndex = Math.ceil(stockItems.length / 2);
const basicInfo1 = stockItems.splice(0, middleIndex);   
const basicInfo2 = stockItems.splice(-middleIndex);


const USCitizen = () => {
  return (
    <div>
        <div className="Search-Text-Title">
            <span>US Citizen</span>
        </div>
        <div>
            <div className="Basic-Info1">  
                <Table items={basicInfo1} />
            </div>
            <div className="Basic-Info2">  
                <Table items={basicInfo2} />
            </div>
        </div>    
    </div>
  );
}

  export default USCitizen;