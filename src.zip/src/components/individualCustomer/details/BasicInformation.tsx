import Table from "../../common/table";

const stockItems = [
  { label: "OCMD ID", value: "C0000099991"},
  { label: "Title", value: "Mr"},
  { label: "Date of Birth", value: "12/11/1998"},
  { label: "Nationality", value: "Chinese"},
  { label: "Relationship Type", value: "Owner, Insured"},
  { label: "Current Status", value: "Active"},
  { label: "Customer Type", value: "Individual"},
  { label: "Fill Name", value: "Chan Tai Man, Jason"},
  { label: "Gender", value: "M"},
  { label: "Marital Status", value: "Single"},
  { label: "Customer Market Segment Type", value: "Young & Upcoming"},
  { label: "Last Update Datetime", value: "30/06/2021 21:20:30"}
];

const middleIndex = Math.ceil(stockItems.length / 2);
const basicInfo1 = stockItems.splice(0, middleIndex);   
const basicInfo2 = stockItems.splice(-middleIndex);


const BasicInformation = () => {
  return (
    <div>
        <div className="Search-Text-Title">
            <span>Basic Information</span>
        </div>
        <div>
            <div className="Basic-Info1">  
                <Table items={basicInfo1} />
            </div>
            <div className="Basic-Info2">  
                <Table items={basicInfo2} />
            </div>
        </div>    
    </div>
  );
}


export default BasicInformation;


