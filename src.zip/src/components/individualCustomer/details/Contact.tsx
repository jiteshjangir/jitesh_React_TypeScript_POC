import LobDataTable from '../../common/LobDataTable'

const Contact = () => {
  return (
      <div>
        <div className='Search-Text-Title'>
          <span>Contact</span>
        </div>
        <div>
          <LobDataTable />
        </div>  
      </div>
  );
};

export default Contact;