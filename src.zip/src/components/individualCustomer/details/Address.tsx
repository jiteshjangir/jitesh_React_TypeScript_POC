import AddressDataTable from '../../common/AddressDataTable'

const Address = () => {
  return (
      <div>
        <div className='Search-Text-Title'>
          <span>Address</span>
        </div>
      <div>
        <div>
          <div className='Address-LOB-Info'>
            <span>Line of Business - Life</span>
          </div>
          <div className='Address-Lob-Data'>
            <AddressDataTable />
          </div>
        </div>
        <div className='Address-Lob-GI'>
          <div>
            <span className='Address-Lob-GI-Text'>Line of Business - GI</span>
          </div>
          <div className='Address-Lob-Data-GI'>
            <AddressDataTable />
          </div>
        </div>
        <div className='Address-Lob-EB'>
          <div>
            <span className='Address-Lob-GI-Text'>Line of Business - EB</span>
          </div>
          <div className='Address-Lob-Data-GI'>
            <AddressDataTable />
          </div>
        </div>
        <div className='Address-Lob-Pension'>
          <div>
            <span className='Address-Lob-GI-Text'>Line of Business - Pension</span>
          </div>
          <div className='Address-Lob-Data-GI'>
            <AddressDataTable />
          </div>
        </div>
        <div className='Address-Lob-Vitality'>
          <div>
            <span className='Address-Lob-GI-Text'>Line of Business - Vitality</span>
          </div>
          <div className='Address-Lob-Data-GI'>
            <AddressDataTable />
          </div>
        </div>
        <div className='Address-Lob-CIAM'>
          <div>
            <span className='Address-Lob-GI-Text'>Line of Business - CIAM</span>
          </div>
          <div className='Address-Lob-Data-GI'>
            <AddressDataTable />
          </div>
        </div>
      </div>  
    </div>
  );
};

export default Address;