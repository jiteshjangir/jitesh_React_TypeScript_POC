import PolicyDataTable from '../../common/PolicyDataTable'

const Policy = () => {
  return (
      <div>
        <div className='Search-Text-Title'>
          <span>Policy</span>
        </div>
        <div>
        <div>
          <div className='ConnectedParty-LOB-Info'>
            <span>Line of Business - Life</span>
          </div>
          <div className='Policy-Lob-Data-Life'>
            <PolicyDataTable />
          </div>
        </div>
        <div className='Policy-Lob-GI'>
          <div>
            <span className='ConnectedParty-Lob-GI-Text'>Line of Business - GI</span>
          </div>
          <div className='Policy-Lob-Data-GI'>
            <PolicyDataTable />
          </div>
        </div>
        <div className='Policy-Lob-EB'>
          <div>
            <span className='ConnectedParty-Lob-GI-Text'>Line of Business - EB</span>
          </div>
          <div className='Policy-Lob-Data-GI'>
            <PolicyDataTable />
          </div>
        </div>
        <div className='Policy-Lob-Pension'>
          <div>
            <span className='ConnectedParty-Lob-GI-Text'>Line of Business - Pension</span>
          </div>
          <div className='Policy-Lob-Data-GI'>
            <PolicyDataTable />
          </div>
        </div>
        <div className='Policy-Lob-Vitality'>
          <div>
            <span className='ConnectedParty-Lob-GI-Text'>Line of Business - Vitality</span>
          </div>
          <div className='Policy-Lob-Data-GI'>
            <PolicyDataTable />
          </div>
        </div>
        <div className='Policy-Lob-CIAM'>
          <div>
            <span className='ConnectedParty-Lob-GI-Text'>Line of Business - CIAM</span>
          </div>
          <div className='Policy-Lob-Data-GI'>
            <PolicyDataTable />
          </div>
        </div>
      </div>  
      </div>
  );
};
  
export default Policy;