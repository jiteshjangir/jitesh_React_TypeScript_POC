import IdentificationDocumentTable from "../../common/IdentificationDocumentTable";

const IdentificationDocument = () => {
    return (
    <div>
        <div className='Search-Text-Title'>
          <span>Identification Document (ID)</span>
        </div>
        <div>
          <IdentificationDocumentTable />
        </div>  
      </div>
    );
  };
  
  export default IdentificationDocument;