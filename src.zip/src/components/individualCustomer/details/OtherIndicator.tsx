import Table from "../../common/table";

const stockItems = [
  { label: "Direct Marketing Opt-in", value: "Y"},
  { label: "AML Status", value: "-"},
  { label: "FATCA Flag", value: "-"},
  { label: "Data Quality Indicator", value: "-"},
  { label: "AIA HK Customer", value: "Y"},
  { label: "AML Risk Score", value: "-"},
  { label: "PEP Flag", value: "-"},
  { label: "Blacklist", value: "-"},
  { label: "Last Update Date of Periodic RIsk-based Update", value: "-"},
  { label: "AIA MO Customer", value: "N"}
];

const middleIndex = Math.ceil(stockItems.length / 2);
const basicInfo1 = stockItems.splice(0, middleIndex);   
const basicInfo2 = stockItems.splice(-middleIndex);


const OtherIndicator = () => {
  return (
    <div>
        <div className="Search-Text-Title">
            <span>Other Indicator</span>
        </div>
        <div>
            <div className="Basic-Info1">  
                <Table items={basicInfo1} />
            </div>
            <div className="Basic-Info2">  
                <Table items={basicInfo2} />
            </div>
        </div>    
    </div>
  );
}

  export default OtherIndicator;