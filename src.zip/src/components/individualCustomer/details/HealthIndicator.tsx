import Table from "../../common/table";

const stockItems = [
  { label: "Smoker Indicator", value: "Y"},
  { label: "AIDS Limit Checking Indicator", value: "N"},
  { label: "Critical Illness Indicator", value: "N"},
  { label: "Disabled Indicator", value: "Y"}
];

const middleIndex = Math.ceil(stockItems.length / 2);
const basicInfo1 = stockItems.splice(0, middleIndex);   
const basicInfo2 = stockItems.splice(-middleIndex);


const HealthIndicator = () => {
  return (
    <div>
        <div className="Search-Text-Title">
            <span>Health Indicator</span>
        </div>
        <div>
            <div className="Basic-Info1">  
                <Table items={basicInfo1} />
            </div>
            <div className="Basic-Info2">  
                <Table items={basicInfo2} />
            </div>
        </div>    
    </div>
  );
}


export default HealthIndicator;