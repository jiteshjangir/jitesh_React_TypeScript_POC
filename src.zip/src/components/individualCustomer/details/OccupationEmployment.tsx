import Table from "../../common/table";

const stockItems = [
  { label: "Employed Indicator", value: "Y"},
  { label: "Employment Date", value: "12/11/1998"},
  { label: "Occupation Class", value: "-"},
  { label: "Occupation Designation", value: "Chinese"},
  { label: "Name of Business", value: "Insurance"},
  { label: "Source of Wealth", value: "-"},
  { label: "Salary Mode", value: "-"},
  { label: "Declared Net Worth", value: "-"},
  { label: "Employee No.", value: "C0163"},
  { label: "Occupation", value: "IT Manager"},
  { label: "Occupation Type", value: "-"},
  { label: "Employer Name", value: "Single"},
  { label: "Nature of Goods / Service", value: "-"},
  { label: "Declared Annual Income", value: "-"},
  { label: "Salary Currency", value: "-"},
  { label: "Main Industry", value: "-"}
];

const middleIndex = Math.ceil(stockItems.length / 2);
const basicInfo1 = stockItems.splice(0, middleIndex);   
const basicInfo2 = stockItems.splice(-middleIndex);


const OccupationEmployment = () => {
  return (
    <div>
        <div className="Search-Text-Title">
          <span>Occupation and Employment</span>
        </div>
        <div>
            <div className="Basic-Info1">  
                <Table items={basicInfo1} />
            </div>
            <div className="Basic-Info2">  
                <Table items={basicInfo2} />
            </div>
        </div>    
    </div>
  );
}
  
  export default OccupationEmployment;