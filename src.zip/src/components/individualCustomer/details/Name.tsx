import Table from "../../common/table";

const stockItems = [
  { label: "First or Given Name", value: "Tai Man"},
  { label: "Last Name", value: "Chan"},
  { label: "Middle Name", value: "-"},
  { label: "Alias Name", value: "-"}
];

const middleIndex = Math.ceil(stockItems.length / 2);
const basicInfo1 = stockItems.splice(0, middleIndex);   
const basicInfo2 = stockItems.splice(-middleIndex);


const Name = () => {
  return (
    <div>
        <div className="Search-Text-Title">
            <span>Name</span>
        </div>
        <div>
            <div className="Basic-Info1">  
                <Table items={basicInfo1} />
            </div>
            <div className="Basic-Info2">  
                <Table items={basicInfo2} />
            </div>
        </div>    
    </div>
  );
}


export default Name;


