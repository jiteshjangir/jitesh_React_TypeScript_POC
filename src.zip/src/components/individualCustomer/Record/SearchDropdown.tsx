import * as React from 'react';
import MenuItem from '@mui/material/MenuItem';
import Select, { SelectChangeEvent } from '@mui/material/Select';

type selectOptions = {
  searchFilters: { label : string,
  value: string }[]; 
}

function SearchDropdown({ searchFilters }: selectOptions) {
  const [option, setOption] = React.useState('');  
  
  const handleChange = (event: SelectChangeEvent) => {
      setOption(event.target.value);
     };


    return (
      <div>
          <Select
            style={{ minHeight: 5, fontSize:12, borderRadius: 0, width:200}}
            value={option}
            displayEmpty
            onChange={handleChange}
          >  
          <MenuItem value="" disabled>Choose a column field</MenuItem>
            { searchFilters.map(( options) => (
              <MenuItem key={options.label} value={options.value}>{options.label}</MenuItem>
            ))}

          </Select>
      </div>
  );
};
      
  
export default SearchDropdown;