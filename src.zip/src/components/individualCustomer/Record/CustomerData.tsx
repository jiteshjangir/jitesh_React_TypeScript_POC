import { DataGrid } from '@mui/x-data-grid'
import SearchDropdown from "./SearchDropdown";
import '../../Styles/IndividualCustomerRecord.css';


function CustomerData() {

  const options = [
    { label: "OCMD ID", value: "OCMD_ID" },
    { label: "Name", value: "name" },
    { label: "ID Number", value: "id"},
    { label: "Mobile Phone Number", value: "mobilePhoneNumber"},
    { label: "Email Address", value: "emailAddress"}
  ];

  const columns = [ 
    { field: 'id', headerName: 'OCMD_ID', width: 130, fontWeight:800},
    { field: 'fullName', headerName: 'Full Name', width: 150, sortable: false},
    { field: 'dateOfBirth', headerName: 'Date of Birth', width: 150, sortable: false },
    { field: 'primaryIdNumber', headerName: 'Primary ID Number', width: 155, sortable: false },
    { field: 'gender', headerName: 'Gender', width: 110, sortable: false },
    { field: 'Life', headerName: 'Life', width: 70, sortable: false  },
    { field: 'GI', headerName: 'GI', width: 70, sortable: false  },
    { field: 'EB', headerName: 'EB', width: 70, sortable: false  },
    { field: 'PT', headerName: 'PT', width: 70, sortable: false  },
    { field: 'VT', headerName: 'VT', width: 70, sortable: false  },
    { field: 'CIAM', headerName: 'CIAM', width: 75, sortable: false },
    { field: 'lastUpdateDate', headerName: 'Last Update date', width: 150 },
  ];
  
  const rows = [
    { id: 'M001', fullName: 'Snow Jon', dateOfBirth: '19/03/1980', primaryIdNumber: 'A123456(7)', gender: 'M', currentStatus: 'Active', lastUpdateDate: '30/12/2021', Life:'Y', GI:'Y', EB: 'Y', PT: 'Y', VT: 'Y', CIAM: 'Y'},
    { id: 'M002', fullName: 'Lannister Cersei', dateOfBirth: '15/05/1987', primaryIdNumber: 'A123456(7)', gender: 'F', currentStatus: 'Inactive', lastUpdateDate: '11/11/2021', Life:'Y', GI:'N', EB: 'Y', PT: 'N', VT: 'N', CIAM: 'Y' },
    { id: 'M003', fullName: 'Lannister Jaime', dateOfBirth: '11/11/1990', primaryIdNumber: 'A123456(7)', gender: 'F', currentStatus: 'Active', lastUpdateDate: '03/09/2020', Life:'Y', GI:'N', EB: 'N', PT: 'Y', VT: 'Y', CIAM: 'Y' },
    { id: 'M004', fullName: 'Stark Arya', dateOfBirth: '25/04/1986', primaryIdNumber: 'A123456(7)', gender: 'M', currentStatus: 'Inactive', lastUpdateDate: '13/08/2021', Life:'N', GI:'N', EB: 'Y', PT: 'Y', VT: 'N', CIAM: 'N' },
    { id: 'M005', fullName: 'Targaryen Daenerys', dateOfBirth: '16/12/1982', primaryIdNumber: 'A123456(7)', gender: 'F', currentStatus: 'Active', lastUpdateDate: '21/10/2019', Life:'Y', GI:'Y', EB: 'N', PT: 'Y', VT: 'N', CIAM: 'Y' },
    { id: 'M006', fullName: 'Melisandre Alex', dateOfBirth: '21/10/1991', primaryIdNumber: 'A123456(7)', gender: 'M', currentStatus: 'Active', lastUpdateDate: '30/12/2021', Life:'Y', GI:'Y', EB: 'Y', PT: 'Y', VT: 'Y', CIAM: 'Y' },
    { id: 'M007', fullName: 'Clifford Ferrara', dateOfBirth: '30/01/1985', primaryIdNumber: 'A123456(7)', gender: 'M', currentStatus: 'Inactive', lastUpdateDate: '30/12/2021', Life:'N', GI:'N', EB: 'N', PT: 'N', VT: 'Y', CIAM: 'Y' },
    { id: 'M008', fullName: 'Frances Rossini', dateOfBirth: '26/09/1984', primaryIdNumber: 'A123456(7)', gender: 'F', currentStatus: 'Active', lastUpdateDate: '14/02/2022', Life:'Y', GI:'Y', EB: 'N', PT: 'N', VT: 'N', CIAM: 'Y' },
    { id: 'M009', fullName: 'Roxie Harvey', dateOfBirth: '18/01/1988', primaryIdNumber: 'A123456(7)', gender: 'M', currentStatus: 'Active', lastUpdateDate: '30/12/2021', Life:'Y', GI:'Y', EB: 'Y', PT: 'N', VT: 'N', CIAM: 'N' },
  ];


    return (
      <div>
        <div className='Individual-Customer-Data'>
          <div className='Header'>
            <span className='Header-Text'>Individual Customer Records</span>
          </div>
          <div className='Search-Text'>
            <div>
                <div className='Search-Text-Title'>
                  <span>Search Records</span>
                </div>
                <div className='Search-Instruction'>  
                  <span>Input text of specific column field or filter by Line of Business(LOB) to search customer records</span>
                </div>  
            </div>
            <div>
              <div className='Search-options'>
                  <SearchDropdown searchFilters={options}/>
              </div>
              <div className='Search-Input'>
                <input type='text' placeholder="Input search text" className='Search-Box'/>
              </div>
              <div>
                <button className='Search-Button'>Search</button>
                <button className='Reset-Button'>Reset</button>
              </div>
              <div className='Search-Filter'>
                <span className='Search-Filter-Options'>Line of Business</span>
                <label className='Search-Filter-Options'><input type="checkbox" name="Life"/>Life</label>
                <label className='Search-Filter-Options'><input type="checkbox" name="GI"/>GI</label>
                <label className='Search-Filter-Options'><input type="checkbox" name="Pension"/>Pension(PT))</label>
                <label className='Search-Filter-Options'><input type="checkbox" name="Vitality"/>Vitality(VT)</label>
                <label className='Search-Filter-Options'><input type="checkbox" name="CIAM"/>CIAM</label>
              </div>
            </div>
          </div>  
          <div className='Data-Table'>
            <DataGrid
              sx={{ marginLeft: 2, border: 'none'}}
              className='Data-Record'
              style={{display: "flex", flexDirection: "column-reverse"}}
              rows={rows}
              onRowClick={()=>{console.log('row is clicked')}} 
              columns={columns}
              pageSize={20}
              disableColumnMenu={true}   
              rowsPerPageOptions={[20, 50]}
              checkboxSelection={false}
              componentsProps={{
                pagination: {
                  labelRowsPerPage: 'Records per page'
                }
              }}
            />
          </div>  
        </div>
    </div>
    );
  }

  export default CustomerData;