import CustomerData from './Record/CustomerData'
const IndividualCustomerRecord = () => {
    return(
      <div className='Individual-Customer-Data'>
        <CustomerData />
    </div>
    ) 
  }  
  export default IndividualCustomerRecord;