import './components/Styles/App.css';
const Home = () => {
    return(
      <div>
        <div className="HomePageHeader">
            <h2 className='AppHeader'>Operational Customer Master Database (OCMD) Portal</h2>
        </div>
        <div className='LeftMenu'>
            <span className='LeftMenuOptions'>Customer Records</span>
            <span className='LeftMenuOptions'>Individual</span>
            <span className='LeftMenuOptions'>Corporate</span>
            <span className='LeftMenuOptions'>Data Quality Status</span>
            <span className='LeftMenuOptions'>Remediation</span>
        </div>
    </div>
    ) 
  }  
  export default Home;